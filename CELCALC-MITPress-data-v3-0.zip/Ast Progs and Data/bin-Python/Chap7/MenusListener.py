"""
Implements action listeners for the menu items

Copyright (c) 2018

:author: J. L. Lawrence
:version 3.0, 2018
"""

import sys

import ASTUtils.ASTMsg as ASTMsg
from ASTUtils.ASTPrt import CENTERTXT

import Chap7.ChapEnums
import Chap7.LunarInfoActions as li_actions
import Chap7.OrbitalElementsActions as oe_actions

#==================================================
# Define listeners for about, exit, instructions
#==================================================

def aboutMenuListener(gui):
    """
    Handle a click on the About menu item
    
    :param tkwidget gui: GUI that the About Box is associated with
    """
    gui.showAboutBox()
    


def exitMenuListener():
    """Handle a click on the Exit menu item"""
    if ASTMsg.pleaseConfirm("Are you sure you want to exit?"," "):
        sys.exit()    
    


def instructionsMenuListener(gui):
    """
    Handle a click on the Instructions menu item
    
    :param ASTPrt prt: ASTPrt object instance created by the top level GUI
    """
    gui.clearTextAreas()
    prt = gui.getPrtInstance()
    prt.setBoldFont(True)
    prt.println("Instructions",CENTERTXT)
    prt.setBoldFont(False)
    prt.println()
 
    prt.println("Enter the 'Observer Location and Time' information in the area indicated. This location/time will " +
            "be used in subsequent calculations. You may find it convenient to enter an initial latitude, longitude, " +
            "and time zone in the file DefaultObsLoc.dat in the 'Ast Data Files' directory so that the latitude, " +
            "longitude, and time zone are already filled in with default values when the program starts. When this program " +
            "begins, the date and time will default to the local date and time at which the program is started.")
    prt.println()
    prt.println("Check the 'Show Intermediate Calculations' checkbox if you want to see intermediate results as the " +
            "various calculations are performed. Also, select the appropriate radio button to choose what method to " +
            "use when it is necessary to determine the Sun's true anomaly. The radio button 'EQ of Center' will solve " +
            "the equation of the center while the other two radio buttons solve Kepler's equation. The radio button " +
            "'Simple' uses a simple iteration method while the radio button 'Newton' solves Kepler's equation via the " +
            "Newton/Raphson method. The menu entry 'Lunar Info->Set Termination Critera' allows you to enter the " +
            "termination criteria (in radians) for when to stop iterating to solve Kepler's equation. This radio button " +
            "only affects how the Sun's true anomaly is computed. Finding the Moon's true anomaly is accomplished by " +
            "solving the equation of the center regardless of which of these radio buttons is set.")
    prt.println()
    prt.println("The menu 'Lunar Info' performs various calculations related to the Moon, such as determining its " +
            "location for the current information in the 'Observer Location and Time' data area. The menu " +
            "'Orbital Elements' allow you to load data files that contain the Sun and Moon's orbital elements referenced to " +
            "a standard epoch. By default, orbital elements for the standard epoch J2000 are loaded when this program " +
            "starts up. The menu entry 'Orbital Elements->Load Orbital Elements' allows you to load and use orbital elements " +
            "referenced to some other epoch.")

    prt.resetCursor()
   


#==================================================
# Define listener for the Conversion menu items
#==================================================

def menuListener(calcToDo,gui):
    """
    Handle a click on the menu items
    
    :param CalculationType calcToDo: the calculation to perform
    :param tkwidget gui: GUI object to which menu items are associated
    """
    cen = Chap7.ChapEnums.CalculationType           # shorten to make typing easier!!!
    
    #**************** Lunar Info Menu
    if (calcToDo == cen.MOON_LOCATION):
        li_actions.calcMoonPosition(gui)
    elif (calcToDo == cen.MOON_RISE_SET):
        li_actions.calcMoonRiseSet(gui)
    elif (calcToDo == cen.MOON_DIST_AND_ANG_DIAMETER):
        li_actions.calcDistAndAngDiameter(gui)
    elif (calcToDo == cen.MOON_PHASES_AND_AGE):
        li_actions.calcMoonPhase(gui)
    elif (calcToDo == cen.MOON_PERCENT_ILLUMINATED):
        li_actions.calcMoonPercentIllum(gui)
    elif (calcToDo == cen.TERM_CRITERIA):
        li_actions.setTerminationCriteria(gui)
    
    #************* Orbital Elements menu
    elif (calcToDo == cen.LOAD_ORBITAL_ELEMENTS):
        oe_actions.loadOrbitalElements(gui)
    elif (calcToDo == cen.SHOW_ORBITAL_ELEMENTS):
        oe_actions.showMoonsOrbitalElements(gui)

    else:
        ASTMsg.errMsg("No appropriate menu item has been selected. Choose an item\n" +
                      "from the 'Lunar Info' or 'Orbital Elements' menu and try again.",
                      "No Menu Item Selected")



#=========== Main entry point ===============
if __name__ == '__main__':
    pass
