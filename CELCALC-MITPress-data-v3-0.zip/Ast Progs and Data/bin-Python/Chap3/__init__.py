"""
This is the program for Chapter 3 of the book
'Celestial Calculations.'


Copyright (c) 2018

:author: J. L. Lawrence
:version 3.0, 2018
"""

# No initialization is needed
pass
